/*package Controller;

import java.util.ArrayList;

public class ConcreteObserver implements Observer{
	String name;

	public ConcreteObserver(String name) {
		super();
		this.name = name;
	}
	
	@Override
	public void updateP(Object obj) {
		if(obj instanceof ConcreteSubject)
		{
			ConcreteObserver po=(ConcreteObserver) obj;
			//po.getState();
		}
	}
}
*/